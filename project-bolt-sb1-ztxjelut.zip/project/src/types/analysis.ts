export interface SensorData {
  [key: string]: number | string;
}

export interface AnalysisData {
  rawData: SensorData[];
  processedData: SensorData[];
  classDistribution: { [key: string]: number };
  topFeatures: string[];
  correlationMatrix: number[][];
  featureImportances: { [key: string]: number };
  anomalies: SensorData[];
  modelMetrics: {
    accuracy: number;
    precision: number;
    recall: number;
    f1Score: number;
    rocAuc: number;
  };
  confusionMatrix: number[][];
  predictions: {
    actual: number[];
    predicted: number[];
    probabilities: number[];
  };
}